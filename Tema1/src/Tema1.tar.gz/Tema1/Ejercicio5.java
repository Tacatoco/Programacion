package Tema1;

public class Ejercicio5 {
    public static void main(String[] args) {

    System.out.println("SE VAN A MOSTRAR LAS SIGUIENTES OPERACIONES");

     double Oper1 = 24 % 5;

     double Oper2 = (2.7 / 2) + 2.5;

     double Oper3 = (10.8 / 2) + 2;

     int Oper4 = (4 + 6) * 3 + 2 * (5 - 1);

     double Oper5 = (5 / 2) + (17 % 3);

     boolean Oper6 = 7 >= 5 || 27 != 8;

     boolean Oper7 = (45 <= 7) || ! (5>=7);

     double Oper8 = (27 % 4) + (15 / 4);

     double Oper9 = (37 / 4) * 4 - 2;

     boolean Oper10 = (25>= 7) && ! (7 <= 2);

     boolean Oper11 = ('H'<'J') && ('9'!= '7');

     boolean Oper12 = (25 > 20) && (13 > 5);

     boolean Oper13 = (10 + 4 < 15 - 3) || (2 * 5 + 1 > 14 - 2 * 2);

     boolean Oper14 = 4 * 2 <= 8 || 2 * 2 < 5 && 4 > 3 + 1;

     boolean Oper15 = 10 <= 2 * 5 && 3 < 4 || ! (8 > 7) && 3 * 2 <= 4 * 2 - 1;


     System.out.println("24 % 5 = " + Oper1);
     System.out.println("(2.7 / 2) + 2.5 =" + Oper2);
     System.out.println("(10.8 / 2) + 2 = " + Oper3);
     System.out.println("(4 + 6) * 3 + 2 * (5 - 1) = " + Oper4);
     System.out.println("(5 / 2) + (17 % 3) = " + Oper5);
     System.out.println("7 >= 5 || 27 != 8 = " + Oper6);
     System.out.println("(45 <= 7) || ! (5>=7) = " + Oper7);
     System.out.println("(27 % 4) + (15 / 4) = " + Oper8);
     System.out.println("(37 / 4) * 4 - 2 = " + Oper9);
     System.out.println("(25>= 7) && ! (7 <= 2) = " + Oper10);
     System.out.println("('H'<'J') && ('9'!= '7') = " + Oper11);
     System.out.println("(25 > 20) && (13 > 5) = " + Oper12);
     System.out.println("(10 + 4 < 15 - 3) || (2 * 5 + 1 > 14 - 2 * 2) = " + Oper13);
     System.out.println("4 * 2 <= 8 || 2 * 2 < 5 && 4 > 3 + 1 = " + Oper14);
     System.out.println("10 <= 2 * 5 && 3 < 4 || ! (8 > 7) && 3 * 2 <= 4 * 2 - 1 = " + Oper15);





    }
}
